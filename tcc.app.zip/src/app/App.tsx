import { useState } from "react";
import {
  LayoutDashboard,
  Building2,
  CalendarClock,
  BarChart2,
  Bell,
  Settings,
  FileText,
  Plus,
  ChevronRight,
  X,
  ArrowLeft,
  CheckCircle,
  XCircle,
  Clock,
  Download,
  Eye,
  MoreHorizontal,
  Upload,
  TrendingUp,
  AlertTriangle,
  Search,
  LogOut,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

/* ─── Types ─────────────────────────────────────────────────────────────── */

type Section = "dashboard" | "empresas" | "agenda" | "relatorios" | "notificacoes" | "configuracoes";

interface Company {
  id: string;
  nome: string;
  cnpj: string;
  regime: string;
  cor: string;
  nfeMes: number;
  valorMes: string;
  pendencias: number;
}

/* ─── Data ───────────────────────────────────────────────────────────────── */

const REGIMES = ["Simples Nacional", "Lucro Presumido", "Lucro Real", "MEI"];
const COLORS = ["#1A56A8", "#16A34A", "#7C3AED", "#D97706", "#C8102E", "#0891B2"];

const INITIAL_COMPANIES: Company[] = [
  { id: "1", nome: "Alfa Comércio Ltda", cnpj: "12.345.678/0001-99", regime: "Lucro Presumido", cor: "#1A56A8", nfeMes: 347, valorMes: "R$ 261.400", pendencias: 3 },
  { id: "2", nome: "Inova Soluções ME", cnpj: "45.678.901/0001-23", regime: "Simples Nacional", cor: "#16A34A", nfeMes: 58, valorMes: "R$ 42.700", pendencias: 0 },
  { id: "3", nome: "Delta Agro Produtos S.A.", cnpj: "77.889.900/0001-11", regime: "Lucro Real", cor: "#7C3AED", nfeMes: 212, valorMes: "R$ 895.300", pendencias: 1 },
];

const INVOICES = [
  { numero: "NF-e 000.041.823", emissao: "20/05/2026", destinatario: "Tecnomax Distribuidora Ltda", cnpj: "12.345.678/0001-99", valor: "R$ 14.850,00", status: "autorizada" },
  { numero: "NF-e 000.041.822", emissao: "20/05/2026", destinatario: "Grupo Renovar Comercial S.A.", cnpj: "98.765.432/0001-00", valor: "R$ 3.290,00", status: "autorizada" },
  { numero: "NF-e 000.041.821", emissao: "19/05/2026", destinatario: "Inova Soluções ME", cnpj: "45.678.901/0001-23", valor: "R$ 7.120,00", status: "pendente" },
  { numero: "NF-e 000.041.820", emissao: "19/05/2026", destinatario: "Ferreira & Cia Importação", cnpj: "33.221.100/0001-55", valor: "R$ 22.400,00", status: "autorizada" },
  { numero: "NF-e 000.041.819", emissao: "18/05/2026", destinatario: "Delta Agro Produtos S.A.", cnpj: "77.889.900/0001-11", valor: "R$ 9.670,00", status: "cancelada" },
];

const CHART_DATA = [
  { mes: "Nov", valor: 184200 },
  { mes: "Dez", valor: 210500 },
  { mes: "Jan", valor: 198700 },
  { mes: "Fev", valor: 234100 },
  { mes: "Mar", valor: 251800 },
  { mes: "Abr", valor: 278300 },
  { mes: "Mai", valor: 261400 },
];

const AGENDA_ITEMS = [
  { data: "23/05", empresa: "Alfa Comércio Ltda", obrigacao: "DARF PIS/COFINS", cor: "#1A56A8", urgente: true },
  { data: "25/05", empresa: "Inova Soluções ME", obrigacao: "DAS Simples Nacional", cor: "#16A34A", urgente: true },
  { data: "30/05", empresa: "Delta Agro Produtos S.A.", obrigacao: "SPED Fiscal (EFD)", cor: "#7C3AED", urgente: false },
  { data: "31/05", empresa: "Alfa Comércio Ltda", obrigacao: "DCTF Mensal", cor: "#1A56A8", urgente: false },
  { data: "05/06", empresa: "Delta Agro Produtos S.A.", obrigacao: "EFD-Contribuições", cor: "#7C3AED", urgente: false },
  { data: "10/06", empresa: "Inova Soluções ME", obrigacao: "PGDAS-D Simples", cor: "#16A34A", urgente: false },
];

const NOTIFICATIONS = [
  { id: "1", tipo: "alerta", titulo: "Certificado digital próximo do vencimento", desc: "Alfa Comércio Ltda — expira em 12 dias", tempo: "Agora", lida: false },
  { id: "2", tipo: "erro", titulo: "NF-e rejeitada pela SEFAZ", desc: "Delta Agro — NF-e 000.041.817 · Código 999", tempo: "2h atrás", lida: false },
  { id: "3", tipo: "sucesso", titulo: "Lote autorizado com sucesso", desc: "Alfa Comércio — 14 notas processadas", tempo: "5h atrás", lida: true },
  { id: "4", tipo: "info", titulo: "Vencimento em 2 dias", desc: "DAS Simples Nacional — Inova Soluções ME", tempo: "Ontem", lida: true },
];

/* ─── Status badge ───────────────────────────────────────────────────────── */

const STATUS_CFG: Record<string, { label: string; color: string; bg: string; icon: React.ReactNode }> = {
  autorizada: { label: "Autorizada", color: "#15803D", bg: "#DCFCE7", icon: <CheckCircle size={10} /> },
  pendente:   { label: "Pendente",   color: "#B45309", bg: "#FEF3C7", icon: <Clock size={10} /> },
  cancelada:  { label: "Cancelada",  color: "#C8102E", bg: "#FEE2E2", icon: <XCircle size={10} /> },
};

function StatusBadge({ status }: { status: string }) {
  const cfg = STATUS_CFG[status];
  if (!cfg) return null;
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium" style={{ color: cfg.color, backgroundColor: cfg.bg }}>
      {cfg.icon}{cfg.label}
    </span>
  );
}

/* ─── Add company modal ──────────────────────────────────────────────────── */

function AddCompanyModal({ onAdd, onClose }: { onAdd: (c: Omit<Company, "id" | "nfeMes" | "valorMes" | "pendencias">) => void; onClose: () => void }) {
  const [nome, setNome]     = useState("");
  const [cnpj, setCnpj]     = useState("");
  const [regime, setRegime] = useState(REGIMES[0]);
  const [cor, setCor]       = useState(COLORS[0]);

  function fmtCnpj(v: string) {
    const d = v.replace(/\D/g, "").slice(0, 14);
    return d.replace(/^(\d{2})(\d)/, "$1.$2").replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3").replace(/\.(\d{3})(\d)/, ".$1/$2").replace(/(\d{4})(\d)/, "$1-$2");
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!nome.trim() || cnpj.length < 18) return;
    onAdd({ nome: nome.trim(), cnpj, regime, cor });
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/25 backdrop-blur-sm">
      <div className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-md mx-4">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <h2 className="text-base text-foreground" style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 400 }}>
            Adicionar empresa
          </h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted transition-colors text-muted-foreground">
            <X size={15} />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="px-6 py-5 space-y-4">
          <div>
            <label className="block text-xs font-medium text-foreground mb-1.5">Razão social</label>
            <input type="text" value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Ex.: Alfa Comércio Ltda"
              className="w-full px-3 py-2.5 rounded-xl border border-border bg-input-background text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary/30 transition" required />
          </div>
          <div>
            <label className="block text-xs font-medium text-foreground mb-1.5">CNPJ</label>
            <input type="text" value={cnpj} onChange={(e) => setCnpj(fmtCnpj(e.target.value))} placeholder="00.000.000/0000-00"
              className="w-full px-3 py-2.5 rounded-xl border border-border bg-input-background text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary/30 transition" style={{ fontFamily: "'DM Mono', monospace" }} required />
          </div>
          <div>
            <label className="block text-xs font-medium text-foreground mb-1.5">Regime tributário</label>
            <select value={regime} onChange={(e) => setRegime(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl border border-border bg-input-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30 transition">
              {REGIMES.map((r) => <option key={r} value={r}>{r}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-foreground mb-2">Cor de identificação</label>
            <div className="flex gap-2">
              {COLORS.map((c) => (
                <button key={c} type="button" onClick={() => setCor(c)}
                  className="w-7 h-7 rounded-full transition-transform hover:scale-110"
                  style={{ backgroundColor: c, outline: cor === c ? `3px solid ${c}` : "3px solid transparent", outlineOffset: 2 }} />
              ))}
            </div>
          </div>
          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose}
              className="flex-1 px-4 py-2.5 rounded-xl border border-border text-sm text-muted-foreground hover:bg-muted transition-colors">
              Cancelar
            </button>
            <button type="submit"
              className="flex-1 px-4 py-2.5 rounded-xl text-sm font-medium text-white transition-opacity hover:opacity-90"
              style={{ backgroundColor: "#1A56A8" }}>
              Adicionar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

/* ─── Sidebar ────────────────────────────────────────────────────────────── */

const NAV = [
  { key: "dashboard",     label: "Dashboard",          icon: LayoutDashboard },
  { key: "empresas",      label: "Empresas",            icon: Building2 },
  { key: "agenda",        label: "Agenda / Vencimentos",icon: CalendarClock },
  { key: "relatorios",    label: "Relatórios gerais",   icon: BarChart2 },
  { key: "notificacoes",  label: "Notificações",        icon: Bell },
  { key: "configuracoes", label: "Configurações",       icon: Settings },
] as const;

function Sidebar({ active, onChange, notifCount }: { active: Section; onChange: (s: Section) => void; notifCount: number }) {
  return (
    <aside className="flex flex-col w-52 shrink-0 h-full border-r border-border bg-card">
      {/* Brand */}
      <div className="px-5 py-5 border-b border-border">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ backgroundColor: "#1A56A8" }}>
            <FileText size={14} color="white" />
          </div>
          <span className="text-sm font-semibold text-foreground tracking-tight" style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 400, fontSize: 15 }}>
            NF Gestor
          </span>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5">
        {NAV.map(({ key, label, icon: Icon }) => {
          const isActive = active === key;
          return (
            <button key={key} onClick={() => onChange(key as Section)}
              className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs transition-colors group"
              style={{
                backgroundColor: isActive ? "#EFF6FF" : "transparent",
                color: isActive ? "#1A56A8" : "#6B6B78",
              }}>
              <div className="flex items-center gap-2.5">
                <Icon size={15} style={{ color: isActive ? "#1A56A8" : "#94A3B8" }} />
                <span className={isActive ? "font-semibold" : "font-medium"}>{label}</span>
              </div>
              {key === "notificacoes" && notifCount > 0 && (
                <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full text-white" style={{ backgroundColor: "#C8102E" }}>
                  {notifCount}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* User */}
      <div className="px-3 py-4 border-t border-border">
        <div className="flex items-center gap-2.5 px-2">
          <div className="w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-semibold text-white shrink-0" style={{ backgroundColor: "#1A56A8" }}>
            RF
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-foreground truncate">Rafael Figueiredo</p>
            <p className="text-[10px] text-muted-foreground">Contador</p>
          </div>
          <button className="text-muted-foreground hover:text-foreground transition-colors">
            <LogOut size={13} />
          </button>
        </div>
      </div>
    </aside>
  );
}

/* ─── Dashboard section ──────────────────────────────────────────────────── */

function Dashboard({ companies }: { companies: Company[] }) {
  const totalNfe  = companies.reduce((s, c) => s + c.nfeMes, 0);
  const totalPend = companies.reduce((s, c) => s + c.pendencias, 0);

  return (
    <div className="flex-1 overflow-y-auto px-8 py-7 space-y-6">
      <div>
        <h1 className="text-2xl text-foreground" style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 400 }}>Dashboard</h1>
        <p className="text-xs text-muted-foreground mt-1">Visão consolidada · maio de 2026</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Empresas ativas",    value: String(companies.length), icon: <Building2 size={15} />, color: "#1A56A8" },
          { label: "NF-e emitidas (mai)",value: String(totalNfe),          icon: <FileText size={15} />,  color: "#16A34A" },
          { label: "Pendências abertas", value: String(totalPend),         icon: <AlertTriangle size={15} />, color: totalPend > 0 ? "#C8102E" : "#16A34A" },
          { label: "Vencimentos em 7 dias", value: "2",                   icon: <CalendarClock size={15} />, color: "#D97706" },
        ].map((k) => (
          <div key={k.label} className="bg-card border border-border rounded-2xl px-5 py-4">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center mb-3" style={{ backgroundColor: k.color + "18", color: k.color }}>
              {k.icon}
            </div>
            <p className="text-2xl font-semibold text-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>{k.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{k.label}</p>
          </div>
        ))}
      </div>

      {/* Chart + upcoming */}
      <div className="grid grid-cols-5 gap-4">
        <div className="col-span-3 bg-card border border-border rounded-2xl p-5">
          <p className="text-sm font-semibold text-foreground">Volume total emitido</p>
          <p className="text-xs text-muted-foreground mt-0.5 mb-5">Todas as empresas · últimos 7 meses</p>
          <ResponsiveContainer width="100%" height={160}>
            <AreaChart data={CHART_DATA} margin={{ top: 0, right: 0, left: -18, bottom: 0 }}>
              <defs>
                <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#1A56A8" stopOpacity={0.12} />
                  <stop offset="95%" stopColor="#1A56A8" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="mes" tick={{ fontSize: 10, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "#94A3B8" }} axisLine={false} tickLine={false} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
              <Tooltip contentStyle={{ fontSize: 11, border: "1px solid rgba(0,0,0,0.08)", borderRadius: 10, boxShadow: "0 4px 16px rgba(0,0,0,0.08)" }}
                formatter={(v: number) => [`R$ ${v.toLocaleString("pt-BR")}`, "Total emitido"]} />
              <Area type="monotone" dataKey="valor" stroke="#1A56A8" strokeWidth={2} fill="url(#g1)" dot={false} activeDot={{ r: 4, fill: "#1A56A8" }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="col-span-2 bg-card border border-border rounded-2xl p-5">
          <p className="text-sm font-semibold text-foreground mb-1">Próximos vencimentos</p>
          <p className="text-xs text-muted-foreground mb-4">Obrigações dos próximos 30 dias</p>
          <div className="space-y-3">
            {AGENDA_ITEMS.slice(0, 4).map((item, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-10 text-center shrink-0">
                  <p className="text-[10px] font-bold" style={{ color: item.urgente ? "#C8102E" : "#6B6B78" }}>{item.data}</p>
                </div>
                <div className="w-1 h-7 rounded-full shrink-0" style={{ backgroundColor: item.cor }} />
                <div className="min-w-0">
                  <p className="text-xs font-medium text-foreground truncate">{item.obrigacao}</p>
                  <p className="text-[10px] text-muted-foreground truncate">{item.empresa}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Company overview */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        <div className="px-5 py-4 border-b border-border">
          <p className="text-sm font-semibold text-foreground">Resumo por empresa</p>
        </div>
        <table className="w-full text-xs">
          <thead>
            <tr style={{ backgroundColor: "#F7F6F2" }}>
              {["Empresa", "Regime", "NF-e / mês", "Volume (mai)", "Pendências"].map((col) => (
                <th key={col} className="px-5 py-2.5 text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{col}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {companies.map((c) => (
              <tr key={c.id} className="border-t border-border hover:bg-muted/30 transition-colors">
                <td className="px-5 py-3.5">
                  <div className="flex items-center gap-2.5">
                    <div className="w-6 h-6 rounded-lg flex items-center justify-center text-white text-[10px] font-bold shrink-0" style={{ backgroundColor: c.cor }}>{c.nome[0]}</div>
                    <span className="font-medium text-foreground">{c.nome}</span>
                  </div>
                </td>
                <td className="px-5 py-3.5 text-muted-foreground">{c.regime}</td>
                <td className="px-5 py-3.5 font-medium text-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>{c.nfeMes}</td>
                <td className="px-5 py-3.5 font-medium text-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>{c.valorMes}</td>
                <td className="px-5 py-3.5">
                  <span className="font-semibold" style={{ color: c.pendencias > 0 ? "#C8102E" : "#15803D", fontFamily: "'DM Mono', monospace" }}>
                    {c.pendencias}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ─── Empresas section ───────────────────────────────────────────────────── */

function Empresas({ companies, onAdd }: { companies: Company[]; onAdd: () => void }) {
  const [selected, setSelected] = useState<Company | null>(null);
  const [nfeFilter, setNfeFilter] = useState("todas");

  if (selected) {
    const filtered = INVOICES.filter((inv) => nfeFilter === "todas" || inv.status === nfeFilter);
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Company header */}
        <div className="shrink-0 px-8 pt-6 pb-0 border-b border-border bg-background">
          <button onClick={() => setSelected(null)} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors mb-5">
            <ArrowLeft size={13} />Empresas
          </button>
          <div className="flex items-end justify-between pb-0">
            <div className="flex items-center gap-4">
              <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white text-base font-bold shrink-0" style={{ backgroundColor: selected.cor }}>
                {selected.nome[0]}
              </div>
              <div>
                <h1 className="text-xl text-foreground leading-tight" style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 400 }}>{selected.nome}</h1>
                <div className="flex items-center gap-2.5 mt-0.5">
                  <span className="text-xs text-muted-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>{selected.cnpj}</span>
                  <span className="text-muted-foreground text-xs">·</span>
                  <span className="text-xs text-muted-foreground">{selected.regime}</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-8 pb-4">
              {[
                { label: "NF-e / mês", value: String(selected.nfeMes) },
                { label: "Volume (mai)", value: selected.valorMes },
                { label: "Pendências", value: String(selected.pendencias), alert: selected.pendencias > 0 },
              ].map((k) => (
                <div key={k.label} className="text-right">
                  <p className="text-lg font-semibold" style={{ fontFamily: "'DM Mono', monospace", color: k.alert ? "#C8102E" : "#0F1629" }}>{k.value}</p>
                  <p className="text-[10px] text-muted-foreground">{k.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Tabs */}
          <div className="flex mt-2">
            {[
              { key: "nfe", label: "Notas Fiscais" },
              { key: "config", label: "Configurações" },
            ].map(({ key, label }) => (
              <button key={key} onClick={() => {}}
                className="px-4 py-2.5 text-xs font-medium border-b-2 transition-colors"
                style={{ borderColor: key === "nfe" ? "#1A56A8" : "transparent", color: key === "nfe" ? "#1A56A8" : "#6B6B78" }}>
                {label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-8 py-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              {["todas", "autorizada", "pendente", "cancelada"].map((f) => (
                <button key={f} onClick={() => setNfeFilter(f)}
                  className="px-3 py-1.5 rounded-xl text-xs font-medium transition-colors capitalize"
                  style={{ backgroundColor: nfeFilter === f ? "#1A56A8" : "#ECEAE3", color: nfeFilter === f ? "white" : "#6B6B78" }}>
                  {f === "todas" ? "Todas" : f.charAt(0).toUpperCase() + f.slice(1) + "s"}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-border text-xs text-muted-foreground hover:bg-muted transition-colors">
                <Upload size={12} />Importar XML
              </button>
              <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-white hover:opacity-90 transition-opacity" style={{ backgroundColor: "#1A56A8" }}>
                <Plus size={13} />Emitir NF-e
              </button>
            </div>
          </div>

          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            <table className="w-full text-xs">
              <thead>
                <tr style={{ backgroundColor: "#F7F6F2" }}>
                  {["Número", "Emissão", "Destinatário", "Valor", "Status", ""].map((col) => (
                    <th key={col} className="px-5 py-2.5 text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{col}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((inv) => (
                  <tr key={inv.numero} className="border-t border-border hover:bg-muted/30 transition-colors group">
                    <td className="px-5 py-3.5 font-medium text-foreground" style={{ fontFamily: "'DM Mono', monospace", fontSize: 11 }}>{inv.numero}</td>
                    <td className="px-5 py-3.5 text-muted-foreground whitespace-nowrap">{inv.emissao}</td>
                    <td className="px-5 py-3.5">
                      <p className="font-medium text-foreground">{inv.destinatario}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5" style={{ fontFamily: "'DM Mono', monospace" }}>{inv.cnpj}</p>
                    </td>
                    <td className="px-5 py-3.5 font-semibold text-foreground whitespace-nowrap" style={{ fontFamily: "'DM Mono', monospace" }}>{inv.valor}</td>
                    <td className="px-5 py-3.5"><StatusBadge status={inv.status} /></td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1 rounded hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"><Eye size={13} /></button>
                        <button className="p-1 rounded hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"><Download size={13} /></button>
                        <button className="p-1 rounded hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"><MoreHorizontal size={13} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="px-5 py-3 border-t border-border flex justify-between items-center">
              <p className="text-[10px] text-muted-foreground">{filtered.length} nota{filtered.length !== 1 ? "s" : ""} encontrada{filtered.length !== 1 ? "s" : ""}</p>
              <button className="text-[10px] font-semibold hover:underline" style={{ color: "#1A56A8" }}>Ver histórico completo →</button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto px-8 py-7">
      <div className="flex items-end justify-between mb-7">
        <div>
          <h1 className="text-2xl text-foreground" style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 400 }}>Empresas</h1>
          <p className="text-xs text-muted-foreground mt-1">{companies.length} empresa{companies.length !== 1 ? "s" : ""} cadastrada{companies.length !== 1 ? "s" : ""}</p>
        </div>
        <button onClick={onAdd}
          className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium text-white hover:opacity-90 transition-opacity"
          style={{ backgroundColor: "#1A56A8" }}>
          <Plus size={14} />Adicionar empresa
        </button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {companies.map((c) => (
          <button key={c.id} onClick={() => setSelected(c)}
            className="group bg-card border border-border rounded-2xl p-5 text-left hover:shadow-md hover:border-primary/25 transition-all duration-200">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white text-base font-bold shrink-0" style={{ backgroundColor: c.cor }}>
                  {c.nome[0]}
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground leading-tight group-hover:text-primary transition-colors">{c.nome}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5" style={{ fontFamily: "'DM Mono', monospace" }}>{c.cnpj}</p>
                </div>
              </div>
              <ChevronRight size={14} className="text-muted-foreground group-hover:text-primary transition-colors mt-1 shrink-0" />
            </div>

            <div className="mt-4 pt-4 border-t border-border grid grid-cols-3 gap-3">
              {[
                { v: String(c.nfeMes), l: "NF-e / mês" },
                { v: c.valorMes, l: "Mai 2026" },
                { v: String(c.pendencias), l: "Pendências", alert: c.pendencias > 0 },
              ].map((stat) => (
                <div key={stat.l}>
                  <p className="text-sm font-semibold truncate"
                    style={{ fontFamily: "'DM Mono', monospace", color: stat.alert ? "#C8102E" : "#0F1629" }}>
                    {stat.v}
                  </p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{stat.l}</p>
                </div>
              ))}
            </div>

            <div className="mt-3">
              <span className="text-[10px] px-2 py-0.5 rounded-full font-medium" style={{ backgroundColor: c.cor + "18", color: c.cor }}>
                {c.regime}
              </span>
            </div>
          </button>
        ))}

        <button onClick={onAdd}
          className="border-2 border-dashed border-border rounded-2xl p-5 flex flex-col items-center justify-center gap-2.5 hover:border-primary/30 hover:bg-primary/5 transition-all min-h-[168px] group">
          <div className="w-9 h-9 rounded-full border-2 border-dashed border-border flex items-center justify-center group-hover:border-primary/30 transition-colors">
            <Plus size={15} className="text-muted-foreground group-hover:text-primary transition-colors" />
          </div>
          <p className="text-xs font-medium text-muted-foreground group-hover:text-primary transition-colors">Adicionar empresa</p>
        </button>
      </div>
    </div>
  );
}

/* ─── Agenda section ─────────────────────────────────────────────────────── */

function Agenda() {
  return (
    <div className="flex-1 overflow-y-auto px-8 py-7">
      <div className="mb-7">
        <h1 className="text-2xl text-foreground" style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 400 }}>Agenda / Vencimentos</h1>
        <p className="text-xs text-muted-foreground mt-1">Obrigações fiscais dos próximos 30 dias</p>
      </div>

      <div className="grid grid-cols-5 gap-4">
        <div className="col-span-3 space-y-2">
          {AGENDA_ITEMS.map((item, i) => (
            <div key={i} className="bg-card border border-border rounded-2xl px-5 py-4 flex items-center gap-4">
              <div className="text-center w-12 shrink-0">
                <p className="text-xs font-bold" style={{ color: item.urgente ? "#C8102E" : "#6B6B78" }}>{item.data}</p>
              </div>
              <div className="w-1 h-10 rounded-full shrink-0" style={{ backgroundColor: item.cor }} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground">{item.obrigacao}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{item.empresa}</p>
              </div>
              {item.urgente && (
                <span className="px-2 py-1 rounded-xl text-[10px] font-semibold shrink-0" style={{ backgroundColor: "#FEE2E2", color: "#C8102E" }}>
                  Urgente
                </span>
              )}
            </div>
          ))}
        </div>

        <div className="col-span-2 bg-card border border-border rounded-2xl p-5 h-fit">
          <p className="text-sm font-semibold text-foreground mb-4">Resumo do mês</p>
          <div className="space-y-4">
            {[
              { label: "Total de obrigações", value: "6", color: "#1A56A8" },
              { label: "Vencendo em 7 dias",  value: "2", color: "#C8102E" },
              { label: "Concluídas",          value: "0", color: "#16A34A" },
            ].map((s) => (
              <div key={s.label} className="flex items-center justify-between py-2.5 border-b border-border last:border-0">
                <span className="text-xs text-muted-foreground">{s.label}</span>
                <span className="text-sm font-semibold" style={{ fontFamily: "'DM Mono', monospace", color: s.color }}>{s.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── Relatórios gerais section ──────────────────────────────────────────── */

function Relatorios({ companies }: { companies: Company[] }) {
  return (
    <div className="flex-1 overflow-y-auto px-8 py-7">
      <div className="mb-7">
        <h1 className="text-2xl text-foreground" style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 400 }}>Relatórios gerais</h1>
        <p className="text-xs text-muted-foreground mt-1">Relatórios consolidados de todas as empresas</p>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        {[
          { icon: <TrendingUp size={18} />, title: "Faturamento consolidado", desc: "Receita bruta por empresa e período", color: "#1A56A8" },
          { icon: <FileText size={18} />, title: "NF-e emitidas", desc: "Listagem e exportação por competência", color: "#16A34A" },
          { icon: <XCircle size={18} />, title: "Cancelamentos", desc: "Histórico de notas canceladas e motivos", color: "#C8102E" },
          { icon: <CalendarClock size={18} />, title: "Obrigações cumpridas", desc: "Histórico de envios e vencimentos", color: "#7C3AED" },
          { icon: <BarChart2 size={18} />, title: "Comparativo mensal", desc: "Evolução de volume por empresa", color: "#D97706" },
          { icon: <Download size={18} />, title: "Exportação em lote", desc: "XML, PDF e XLSX de múltiplas empresas", color: "#0891B2" },
        ].map((r) => (
          <button key={r.title}
            className="flex flex-col items-start gap-3 bg-card border border-border rounded-2xl p-5 hover:shadow-sm hover:border-primary/25 transition-all text-left group">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ backgroundColor: r.color + "18", color: r.color }}>
              {r.icon}
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">{r.title}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{r.desc}</p>
            </div>
            <span className="text-xs font-semibold group-hover:underline" style={{ color: r.color }}>Gerar relatório →</span>
          </button>
        ))}
      </div>

      <div className="bg-card border border-border rounded-2xl p-5">
        <p className="text-sm font-semibold text-foreground mb-1">Faturamento por empresa</p>
        <p className="text-xs text-muted-foreground mb-5">Últimos 7 meses · valor total emitido</p>
        <ResponsiveContainer width="100%" height={180}>
          <AreaChart data={CHART_DATA} margin={{ top: 0, right: 0, left: -16, bottom: 0 }}>
            <defs>
              <linearGradient id="gRel" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#1A56A8" stopOpacity={0.12} />
                <stop offset="95%" stopColor="#1A56A8" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="mes" tick={{ fontSize: 10, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 10, fill: "#94A3B8" }} axisLine={false} tickLine={false} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
            <Tooltip contentStyle={{ fontSize: 11, border: "1px solid rgba(0,0,0,0.08)", borderRadius: 10 }}
              formatter={(v: number) => [`R$ ${v.toLocaleString("pt-BR")}`, "Emitido"]} />
            <Area type="monotone" dataKey="valor" stroke="#1A56A8" strokeWidth={2} fill="url(#gRel)" dot={false} activeDot={{ r: 4, fill: "#1A56A8" }} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

/* ─── Notificações section ───────────────────────────────────────────────── */

const NOTIF_ICON: Record<string, React.ReactNode> = {
  alerta:  <AlertTriangle size={14} />,
  erro:    <XCircle size={14} />,
  sucesso: <CheckCircle size={14} />,
  info:    <Bell size={14} />,
};
const NOTIF_COLOR: Record<string, { color: string; bg: string }> = {
  alerta:  { color: "#D97706", bg: "#FEF3C7" },
  erro:    { color: "#C8102E", bg: "#FEE2E2" },
  sucesso: { color: "#15803D", bg: "#DCFCE7" },
  info:    { color: "#1A56A8", bg: "#EFF6FF" },
};

function Notificacoes() {
  const [notifs, setNotifs] = useState(NOTIFICATIONS);
  function markAll() { setNotifs((n) => n.map((x) => ({ ...x, lida: true }))); }

  return (
    <div className="flex-1 overflow-y-auto px-8 py-7">
      <div className="flex items-end justify-between mb-7">
        <div>
          <h1 className="text-2xl text-foreground" style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 400 }}>Notificações</h1>
          <p className="text-xs text-muted-foreground mt-1">{notifs.filter((n) => !n.lida).length} não lida{notifs.filter((n) => !n.lida).length !== 1 ? "s" : ""}</p>
        </div>
        <button onClick={markAll} className="text-xs font-medium hover:underline" style={{ color: "#1A56A8" }}>
          Marcar todas como lidas
        </button>
      </div>

      <div className="space-y-2 max-w-2xl">
        {notifs.map((n) => {
          const cfg = NOTIF_COLOR[n.tipo];
          return (
            <div key={n.id}
              className="bg-card border border-border rounded-2xl px-5 py-4 flex items-start gap-4 transition-colors"
              style={{ opacity: n.lida ? 0.6 : 1 }}>
              <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 mt-0.5" style={{ backgroundColor: cfg.bg, color: cfg.color }}>
                {NOTIF_ICON[n.tipo]}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-4">
                  <p className="text-sm font-semibold text-foreground">{n.titulo}</p>
                  <span className="text-[10px] text-muted-foreground whitespace-nowrap">{n.tempo}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">{n.desc}</p>
              </div>
              {!n.lida && <div className="w-2 h-2 rounded-full mt-1.5 shrink-0" style={{ backgroundColor: "#1A56A8" }} />}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ─── Configurações section ──────────────────────────────────────────────── */

function Configuracoes() {
  return (
    <div className="flex-1 overflow-y-auto px-8 py-7">
      <div className="mb-7">
        <h1 className="text-2xl text-foreground" style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 400 }}>Configurações</h1>
        <p className="text-xs text-muted-foreground mt-1">Preferências do sistema e do escritório</p>
      </div>

      <div className="grid grid-cols-2 gap-6 max-w-3xl">
        {[
          {
            title: "Escritório contábil",
            rows: [
              { label: "Nome",            value: "Figueiredo Contabilidade" },
              { label: "CNPJ",            value: "98.765.432/0001-00", mono: true },
              { label: "CRC",             value: "SP-123456/O-7" },
              { label: "Responsável",     value: "Rafael Figueiredo" },
            ],
          },
          {
            title: "Sistema",
            rows: [
              { label: "Versão",          value: "NF Gestor v2.4.1" },
              { label: "Ambiente SEFAZ",  value: "Produção" },
              { label: "Timeout consulta",value: "30 segundos" },
              { label: "Fuso horário",    value: "America/São_Paulo" },
            ],
          },
        ].map((section) => (
          <div key={section.title} className="bg-card border border-border rounded-2xl overflow-hidden">
            <div className="px-5 py-4 border-b border-border">
              <p className="text-sm font-semibold text-foreground">{section.title}</p>
            </div>
            <div className="divide-y divide-border">
              {section.rows.map((row) => (
                <div key={row.label} className="flex items-center justify-between px-5 py-3">
                  <span className="text-xs text-muted-foreground">{row.label}</span>
                  <span className="text-xs font-medium text-foreground" style={{ fontFamily: row.mono ? "'DM Mono', monospace" : "inherit" }}>{row.value}</span>
                </div>
              ))}
            </div>
            <div className="px-5 py-3 border-t border-border">
              <button className="text-xs font-semibold hover:underline" style={{ color: "#1A56A8" }}>Editar →</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─── Root ───────────────────────────────────────────────────────────────── */

export default function App() {
  const [section, setSection]     = useState<Section>("dashboard");
  const [companies, setCompanies] = useState<Company[]>(INITIAL_COMPANIES);
  const [showModal, setShowModal] = useState(false);

  const unreadNotifs = NOTIFICATIONS.filter((n) => !n.lida).length;

  function handleAdd(data: Omit<Company, "id" | "nfeMes" | "valorMes" | "pendencias">) {
    setCompanies((prev) => [...prev, { ...data, id: String(Date.now()), nfeMes: 0, valorMes: "R$ 0", pendencias: 0 }]);
    setShowModal(false);
  }

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background" style={{ fontFamily: "'Inter', sans-serif" }}>
      <Sidebar active={section} onChange={setSection} notifCount={unreadNotifs} />

      {section === "dashboard"     && <Dashboard companies={companies} />}
      {section === "empresas"      && <Empresas companies={companies} onAdd={() => setShowModal(true)} />}
      {section === "agenda"        && <Agenda />}
      {section === "relatorios"    && <Relatorios companies={companies} />}
      {section === "notificacoes"  && <Notificacoes />}
      {section === "configuracoes" && <Configuracoes />}

      {showModal && <AddCompanyModal onAdd={handleAdd} onClose={() => setShowModal(false)} />}
    </div>
  );
}
