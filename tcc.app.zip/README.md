
  # Initial screen for invoice management app

  This is a code bundle for Initial screen for invoice management app. The original project is available at https://www.figma.com/design/5BfbSR2zrPRcNZpEn6aZAE/Initial-screen-for-invoice-management-app.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  